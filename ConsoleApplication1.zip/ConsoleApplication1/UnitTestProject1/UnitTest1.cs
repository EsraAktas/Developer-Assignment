﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApplication1;
using Moq;
using System.Threading.Tasks;

namespace UnitTestProject1
{
   [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void AccountObj_Given_Id_RefreshAmount_Should_Return_Expected_Amount()
        {
            var expectedId = 1;
            //var expectedAmount = new Task<double>() 100D ;
            //Task<double> expectedAmount = 100D;

            Task<double> expectedAmount = Task.Run(() => 100D);
            //Task taskA = Task.Run(() => Thread.Sleep(2000));

            var service = new Mock<IAccountService>();

            service
                .Setup(m => m.GetAccountAmount(expectedId))//the expected method called with provided Id
                .Returns(expectedAmount)//If called as expected what result to return
                .Verifiable();//expected service behavior can be verified


            //the system under test
            var account = new AccountInfo(expectedId, service.Object);
            
            //Act
            //exercise method under test
            account.RefreshAmount();


            //Assert

            //verify that expectations have been met
            service.Verify(); //verify that mocked service behaved as expected
            //Assert.AreEqual(expectedAmount, account.Amount);
        }

 
    }
}